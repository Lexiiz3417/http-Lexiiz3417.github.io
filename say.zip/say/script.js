function sendMessage() {
  var message = document.getElementById('message').value;
  if (message.trim() !== '') {
    // Simpan pesan ke local storage
    var messages = JSON.parse(localStorage.getItem('messages')) || [];
    messages.push(message);
    localStorage.setItem('messages', JSON.stringify(messages));
    // Bersihkan textarea setelah mengirim pesan
    document.getElementById('message').value = '';
    alert('Pesan telah terkirim!');
  } else {
    alert('Harap masukkan pesan Anda.');
  }
}