function validatePIN(event) {
  event.preventDefault();
  var pinInput = document.getElementById('pin').value;
  var correctPIN = "341777"; // PIN yang benar
  if (pinInput === correctPIN) {
    window.location.href = "https://lexiiz3417.github.io/say/received.html"; // Redirect ke halaman messages.html jika PIN benar
  } else {
    var errorMessage = document.getElementById('error');
    errorMessage.style.display = 'block';
  }
}